"""FastAPI inference service for the Zodiac Wardrobe Picker.

Place clothing_mobilenetv2.keras and labels.json in backend/models/ before running.
The model exported by the supplied Colab notebook accepts RGB images in 0..255;
its MobileNetV2 rescaling layer is already included inside the model.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import tensorflow as tf
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from PIL import Image, UnidentifiedImageError

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"
MODEL_PATH = MODEL_DIR / "clothing_mobilenetv2.keras"
LABELS_PATH = MODEL_DIR / "labels.json"
IMAGE_SIZE = (224, 224)

app = FastAPI(title="Zodiac Wardrobe Clothing Classifier", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Local prototype only. Restrict this before public deployment.
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

model: Any = None
label_map: dict[str, str] = {}
load_error: str | None = None


def load_artifacts() -> None:
    global model, label_map, load_error
    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        load_error = (
            "Model files are missing. Put clothing_mobilenetv2.keras and labels.json "
            "inside backend/models/."
        )
        return
    try:
        model = tf.keras.models.load_model(MODEL_PATH)
        with LABELS_PATH.open("r", encoding="utf-8") as f:
            raw = json.load(f)
        label_map = {str(k): str(v) for k, v in raw.items()}
        if not label_map:
            raise ValueError("labels.json is empty")
        load_error = None
    except Exception as exc:  # Keep the API alive so /health can explain the issue.
        model = None
        load_error = f"Could not load model artifacts: {exc}"


load_artifacts()


def to_app_category(label: str) -> str:
    """Map the model's fine-grained classes to the prototype's broad categories."""
    value = "".join(ch for ch in label.lower() if ch.isalnum())
    if "dress" in value:
        return "Dress"
    if "jacket" in value or "coat" in value or "blazer" in value:
        return "Outerwear"
    if any(token in value for token in ("jean", "trouser", "pant", "short")):
        return "Bottom"
    if any(token in value for token in ("shirt", "tshirt", "sweatshirt", "top")):
        return "Top"
    if any(token in value for token in ("shoe", "sandal", "sneaker", "footwear")):
        return "Footwear"
    return "Top"  # Unknown model classes remain editable in the UI.




@app.get('/', include_in_schema=False)
def serve_frontend():
    frontend_path = BASE_DIR.parent / 'index.html'
    return FileResponse(frontend_path)


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok" if model is not None else "model_not_loaded",
        "model_loaded": model is not None,
        "classes": list(label_map.values()),
        "message": load_error or "Model is ready.",
    }


@app.post("/predict")
async def predict(image: UploadFile = File(...)) -> dict[str, Any]:
    if model is None:
        raise HTTPException(status_code=503, detail=load_error or "Model is not loaded")
    if not image.content_type or not image.content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail="Please upload a JPG, PNG, or WEBP image.")
    try:
        contents = await image.read()
        if not contents:
            raise HTTPException(status_code=400, detail="The uploaded image is empty.")
        from io import BytesIO
        with Image.open(BytesIO(contents)) as opened:
            pil_image = opened.convert("RGB").resize(IMAGE_SIZE, Image.Resampling.BILINEAR)
            array = np.asarray(pil_image, dtype=np.float32)[None, ...]  # RGB, 0..255
    except UnidentifiedImageError:
        raise HTTPException(status_code=400, detail="The file is not a valid image.")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not process image: {exc}")

    try:
        probabilities = model.predict(array, verbose=0)[0]
        index = int(np.argmax(probabilities))
        label = label_map.get(str(index))
        if label is None:
            raise ValueError(f"No label found for prediction index {index}")
        confidence = float(probabilities[index])
        return {
            "predicted_label": label,
            "app_category": to_app_category(label),
            "confidence": confidence,
            "confidence_percent": round(confidence * 100, 2),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {exc}")
