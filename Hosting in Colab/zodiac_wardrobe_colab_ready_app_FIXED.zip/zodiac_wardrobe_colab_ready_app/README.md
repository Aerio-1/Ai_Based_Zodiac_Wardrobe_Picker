# Zodiac Wardrobe Picker — Colab-ready application package

This ZIP contains the website frontend and FastAPI backend for the temporary Google Colab + pyngrok demo.

## Upload to Colab

Required:
1. `zodiac_wardrobe_colab_ready_app.zip` — this application package.
2. `clothing_model_bundle.zip` — the trained `.keras` model and `labels.json` from your MobileNetV2 training notebook.

Optional:
3. Kaggle dataset ZIP — only if you want Colab to extract the source dataset for reference or future retraining. It is not needed to host or run the trained model.

The companion Colab notebook extracts the ZIPs inside Colab and copies the `.keras` and `labels.json` files into `backend/models/` automatically. It checks for an existing TensorFlow installation and only installs a Python-compatible version if needed; TensorFlow is intentionally omitted from this ZIP's requirements file.

## API

- `/` — website
- `/health` — backend/model status
- `/predict` — clothing classification endpoint
- `/docs` — interactive API documentation

## Important limitations

- The CNN classifies one main garment per uploaded image; it is not an object detector for a crowded wardrobe photo.
- Training data consists of catalogue/product images. Results on phone photos may vary.
- Dominant colour detection runs in the browser and can be affected by background/lighting. The user can correct it.
- Zodiac colour associations are styling inspiration, not scientific predictions.
- The ngrok link is temporary and publicly accessible to anyone who has it. Do not upload private photos.
